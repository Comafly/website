# SIDE website redesign

A static, framework-free site: HTML shells + SCSS + ES modules. Every word on screen comes from JSON.

## Run it
The pages load their content with `fetch()`, so they must be served over HTTP (opening `index.html` from disk will not work):

```bash
npm install          # only needed to compile SCSS (sass)
npm run build        # compile scss → css/main.css and regenerate the HTML shells
npm run serve        # http://localhost:8080
npm run validate     # lint the JSON: media ids, nav anchors, cross-page links, placeholder links
```

> **Note on the shipped CSS.** `css/main.css` was compiled with a small stand-in SCSS compiler because the build environment had no npm access. The SCSS is written in the standard Dart Sass subset, so `npm run build:css` should produce equivalent output — please diff the two once and keep the real Sass output.

## Where things live
| Path | What |
|---|---|
| `content/site.json` | Navigation (pages, anchors per page), footer, dialogs, every UI string |
| `content/media.json` | Photo catalogue: id → URL, alt text, focal point, tint |
| `content/pages/*.json` | One file per page. `site.json → pages[].file` links a page id (`page.education`) to its file |
| `scss/abstracts/_tokens.scss` | **All** fonts, colours, tones, type scale, spacing, motion tokens |
| `scss/components/` | One partial per component |
| `js/render/` | JSON section/block → DOM |
| `js/fx/`, `js/ui/` | Scroll effects, interactions |
| `js/config.js` | Behaviour knobs (smoothing, effects on/off, retype settings) |

## The ID system
* A page is `<body data-page="page.education">`. That id is looked up in `site.json → pages` to find `content/pages/education.json`.
* Sections have ids like `edu.hero`. A section's `anchor` keeps the original URL fragment (`#curriculum-anchor`).
* Links are written as `"page.enrolment#school-based-anchor"` and resolved to real URLs at render time.
* Photos are referenced by id (`"media": "m.home.hero1"`) and resolved through `media.json`.
* Rich text in JSON strings: `[label](url)`, `**bold**`, `==highlight==`, `{{lang|text}}`; blank line = new paragraph.

## Common jobs
* **Change fonts / colours / sizes** — edit `scss/abstracts/_tokens.scss` (and the matching `$font-import-url`), then `npm run build`.
* **Add a page** — add an entry to `site.json → pages` (and `nav` if it should appear in the menu), create `content/pages/<file>.json`, run `npm run pages`.
* **Add a section type** — write a function that takes the section JSON and returns an element in `js/render/`, register it in `js/render/index.js`.
* **Swap photos** — edit `content/media.json`. The Unsplash ids are unverified; a missing photo falls back to a seeded stock image, then a tinted gradient.
* **Logo** — the mark is a placeholder in `js/core/icons.js` (`brandMark`).
* **Reduced motion** — respects the OS setting; visitors can also toggle it in the footer. Scroll sequences stack, horizontal tracks become swipe strips, text shows its final form.

## Known placeholders
Support content and the news/newsletter/alumni cards are lorem ipsum. Buttons whose destination isn't in the old site (payment downloads, SOEP login, etc.) point to `#`; `npm run validate` lists every one. The contact and login forms are front-end only.

## Round 2 changes
- Palette: ink `#0a1826` (overlay `rgba(10,24,38,.88)`), brand `#10364b`, white, button accent `#bf314b`, yellow accent `#d2ad69` (see `scss/abstracts/_tokens.scss`).
- Removed: cursor follower, glyph-retyping text, image warp filter, home marquee, footer "Learn anywhere" banner and watermark.
- Official logo: `assets/side-logo.png`.
- Pinned-sequence progress is now a column of high-contrast circles on the right edge.
- Image arches curve a single corner.
- Home hero rewritten for smooth scrubbing (opacity/transform only).
- `js/fx/flow.js`: three flowing strands on the right of the page; enable per page with `"meta": {"flow": true}` in the page JSON.

## Round 3 changes
- Hero "scroll" arrow now steps one frame at a time (and onto the next section from the last frame).
- Flow lines render into a narrow right-hand canvas strip (cheaper to paint, smoother scrolling).
- "Three ways to learn": a colour mask sweeps left→right through each frame as you scroll, then fades into the next (`.seq__mask`, driven in `js/fx/sequence.js`).

## Round 4 changes
- Hero "scroll" arrow glides slowly through all frames and on to the stats (any wheel/touch/key input interrupts it).
- New section type `stories` (`js/render/stories.js`, `js/ui/stories.js`, `scss/components/_stories.scss`): scroll-snap carousel of image + byline cards; each opens a native `<dialog>` with the article. Items carry `media`, `eyebrow`, `title`, `byline`, `excerpt`, `article`. Used for the home "Student stories" section (article text is placeholder except the first two).

## Round 5 changes
- Hero: layered masking (incoming photo revealed by a sliding mask panel with a bright leading edge, counter-moving photo, parallax drift, outgoing photo pushed up and dimmed).
- Flow lines: each strand follows its own Catmull-Rom route from lane to lane (full page width), braids gently, stays right on the splash and converges in the footer.
- Mega menu: removed the page-tab row and the "Jump to" blurb; the top nav links now select the panel.

## Round 6 changes
- Flow lines are layered: behind copy/photos, above section backgrounds (section backgrounds move to a `::before` at z -2 while `body.has-flow`); the hero and banner stages carry their own line layer between photo and copy.
- Choreography is scripted in `SCRIPT` at the top of `js/fx/flow.js`: per section, where the bundle travels and which strand (if any) breaks away to swirl around it.

## Round 7 changes
- New section type `spotlight` (`js/render/spotlight.js`, `js/fx/spotlight.js`, `scss/components/_spotlight.scss`): the dance section is now a pinned full-screen scene. Three single-colour (R, G, B) copies of the photo are added together with `mix-blend-mode: screen`; each wipes in from a different edge through a sliding mask panel (the photo counter-slides), drifts in its own parallax layer, then they converge into the true-colour picture. The headline rises word-by-word out of clipping masks. Photo: `m.home.dance` in `content/media.json`.
- Hero sequence: all frames load eagerly, are pre-decoded and stay composited (no `visibility` toggling) so the transition between frames no longer hitches.

## Round 8 changes
- Hero frames: scale/drift are continuous functions of scroll position (no size snap when a photo becomes current).
- `js/fx/smooth.js`: eased wheel/keyboard scrolling (critically-damped spring: eases in and out). Touch, reduced-motion, open dialogs and scrollable inner panes keep native behaviour. Tune `SMOOTH_TIME` at the top of the file.
- Flow lines are now ribbons: each strand is a filled outline whose width swells and tapers (to a hair-line) along its length; widths settle to a steady value where they meet the button (`sample()` in `js/fx/flow.js`).
- `js/fx/settle.js`: pinned stages ease into their pinned position (speed ramps to 0 over 0.9 viewport heights) instead of stopping abruptly. No ease-out on release (it dragged the stage over the next section).
- Dance scene: the jet-black backdrop is now a soft radial light (`.spot__glow`) that drifts as you scroll; the photo blends over it.
- Hero slides: `--seq-step` halved (85vh per frame). Flow ribbons calmer (lower amplitude, longer wavelength, slower drift, narrower max width). Dance stage gets hard paint containment (`contain: paint`, `clip-path`) so its oversized blended layers can never paint outside the stage; the pin ease-in no longer sets `will-change`/`z-index` on stages.

## Round 9
- **WA map** (`home.map`, type `map`): full-screen pinned canvas scene (`js/fx/map.js`, outline in `js/data/wa-outline.js`). Pseudo-3D camera (tilt/yaw/zoom/pan) follows scroll; 287 pins generated from the cluster list in `home.json` drop onto the land, bounce and ripple; counter and region labels follow.
- **Three ways to learn**: yellow ribbon crosses right at Home-based, blue at School-based, red at Blended (`sc.ways` branch in `js/fx/flow.js`).
- Map now replaces the static image in the partners section (`home.partners`, type `map`) and carries its heading, copy, list and CTA. Pins are a sample (≈1 per 9 schools); the counter still counts up to 287.
- Map perf: redraws only when scroll changes, no shadowBlur, 4 slab layers, sparser graticule, dpr cap 1.25; sea gradient is CSS and the page-wide flow canvas shows behind it (no extra host canvas).
- Swimming section: the article text now lives inside the banner (`home.hero-story.body`) and fades/rises over the right of the photo; ribbons run along the far right for the scene.
- Map pins are classic hollow teardrops in our yellow, each a slightly different shade. tokens: "mega" type style uses ls: 0 (user change, keep).
- Three ways to learn is now a full-screen `stage` sequence (tinted photos masked in over each other; tints sun/aqua/clay). The 'What We Offer' caption paragraph was removed. Map pins scaled down.
- Stage slides: number + title sit under the section heading; larger body copy + button is vertically centred and fades on with scroll for each slide.
- Header: Contact is now the plain icon button and Login the yellow pill; Login opens a portal-links modal (content in site.json dialogs.login; Absentee Reporting Form href is a placeholder '#').
- Home hero is now a one-screen auto-cycling slideshow (js/fx/herocycle.js): 8s per slide, pills + fill timelines, pause button, no scroll pinning; the scroll cue glides to the next section.
- Wheel/keyboard eased scrolling removed (native scrolling; `fx/smooth.js` deleted). The pin ease-in (`fx/settle.js`) stays.
- Root text scale: at ≤1920px wide `html { font-size: 92% }` in `scss/base/_reset.scss` scales every rem-based size; change that one value to tune.
- Payments: Home-based charges use the new `rowlist` section; Secondary charges use `tabs` variant `side` (options left, details right); `section--tight-*` classes cut the gap between Primary and Secondary.
- Buttons (.btn, .pill, .chip, .icon-btn): hover is an instant colour change only; the expanding-circle fill, lift/rotate, label roll and mouse-follow (magnetic) are gone.

### Nav hover height
Opening the mega dropdown no longer expands a compact navbar; `is-compact` is kept while `is-mega` is set, and the panel is offset to the current bar height.

### Ways ribbons
Ribbons now cross along the top of the screen (as each slide settles) and curve down the right side, rather than cutting diagonally through the centre.

### Vision & Values
Added "Our Vision" label (content: `statementLabel`). Values: letters rise in one by one, a counter and underline draw in, and the body gets a self-drawing accent rule instead of a blurred card. Applied your letter-spacing removal and Alex Saffy title.

### Progress marks
Sequence progress dots are now minimal (small dots, active one stretches to a yellow bar) and are buttons that scroll to their frame.

### Values section, scrubbed
Values are now driven continuously by scroll (no snapping): words drift while current, letters lift out then the next rise in (sequential, no overlap), paragraph arrives a beat later, background melts over a wide band with a drifting glow, plus a progress hairline. 150vh of scroll per value.

### Documents
Featured document cards are now compact horizontal rows (small thumbnail, title, icon).

Featured document cards removed from About > School Documents.

About page order: Vision & Values, Campus, School Documents, History, Careers (nav order matched).

### News
Community news is now the same stories carousel as home. Card image eases up 12% on hover; "View all articles" sits beside the arrows; article modal close button is white on a dark disc.

### Events & Calendar
Community page: Events + Calendar merged into one full-height `calendar` section (js/render/calendar.js, scss/components/_calendar.scss), fed by content/calendar.ics (parsed in the browser). Left: events by month from the current month; right: ARIA-grid month view / year overview with eased transitions. Keyboard: arrows, Home/End, PageUp/PageDown (Shift = year). Reduced-motion respected; live-region announcements; colour never the only cue. Replace content/calendar.ics to update the data.

### Round tweaks
Calendar list: descriptions removed; month grid now uses the full panel height (CSS grid layout on the ARIA grid). Deputy Principal portrait is smaller (`feature--portrait`). "Open X" link removed from the nav dropdown.

### Calendar round 3
Calendar: only the eyebrow shows (title/lead removed; section still has an accessible name). Events open in a modal (from list titles, calendar chips or a day) that holds the description and "More information" link; days with several events list the others in the modal. Search box above the list filters events (title, category, description, date) and dims non-matching chips in the month grid.

### Newsletter
New `newsletter` section type: the first item is the current issue (large cover + actions), the rest are listed under "Previous issues".

### Newsletter book
Newsletter is a pinned, scroll-driven 3D book (js/fx/book.js, render/newsletter.js, scss/components/_newsletter.scss): cover opens, leaves flick over, spread ends on the actions. Cover image: assets/images/previews/2025_Newsletter_Semester_1.jpg (media id m.comm.newsletter.latest). Inner pages come from `items[0].pages` (typographic teasers; give a page `media` to show a real page image instead). Narrow screens / reduced motion: not pinned, turned with prev/next buttons.

### Home welcome portrait
The principal's photo on the home page is now a compact portrait (max 36rem wide, 4:5) centred in its column, with the rounded corner on the **top-left** (`.feature--arch .feature__media`). The Education page portrait keeps its own smaller size.

### Newsletter, reworked as turning sheets
The section is now a pinned stage of three full-section sheets (current issue with its cover filling the left half, "In this issue", previous issues). Scrolling turns the top sheet like a page, hinged on its left edge with a moving shade, and the next sheet's content rises into place (`js/fx/book.js`, `scss/components/_newsletter.scss`, `js/render/newsletter.js`). On narrow screens or reduced motion the sheets simply stack. Focusing a link on a turned sheet scrolls to that sheet.

### Calendar modal
Event modal is now a light card (white, ink text, category-coloured top band, clay button) so it stands out from the dark backdrop.

### Alumni story modals
Cards in the Alumni Stories section now open the same article dialog as the news stories. Add `eyebrow`, `byline` and `article` (array of paragraphs) to any person-card item and it becomes clickable (`js/render/collections.js`, shared `storyDialog` in `js/render/stories.js`).

### Education overview statement
`edu.overview` uses `size: h2` and `class: statement--framed`: smaller main text, with the title (left, rule before) and caption (right, rule after) set larger and equally spaced above and below. Reusable on any statement section.

### How It Works rebuilt
New `howit` section type (`js/render/howit.js`, `scss/components/_howit.scss`): intro, Moodle and Webex cards with illustrated mock-ups and short point lists, then the two ways to join (home/road, in class) as alternating photo rows. All copy is in `edu.how` in `content/pages/education.json`.

### Learning at SIDE merged
The separate "Learning at SIDE" scroller (`edu.tools`) is removed. Its key points now sit in How It Works: extra Moodle/Webex bullets plus a full-width In Person card.

### Education page restructure
Removed "Welcome to SIDE Primary" and the Deputy's message. Primary and Secondary pathways are combined into one **Pathways** section (Home-based, School-based); a new **Blended Pathway** section states it is for Secondary students only. **Curriculum** is a new `curriculum` section type (`js/render/curriculum.js`): the Primary / Secondary buttons are the headers, a narrow learning-area list sits on the left and the selected area fills a details panel on the right (first area selected by default). The "Or pick a year group" buttons now jump to the matching curriculum level.

### Education pathways tidy-up
Removed the year-group picker and the Secondary welcome section. Pathways is now "Primary & Secondary Pathways" with the SCSA accreditation line beneath it; Blended Pathway's two intro lines are merged into one. Cards sit three to a row on wide screens and stack below the lg breakpoint (prose sections accept `wide: true`).

### Pathway picker restyled; Home-based Learn more button removed
"Choosing Your Pathway" is now a compact two-column layout: title left, one tidy card on the right holding numbered questions with small chips and a tight result box.

### How It Works as pinned scroll stages
Tools: Moodle card first; Webex fades in from the right and lands 3/4 over it; In Person does the same over Webex. Ways: photo left + 01 right; the 01 text slides left and becomes 02 while the second photo arrives on the right. `js/fx/hstage.js` writes `--s1/--s2` / `--s`; CSS does the rest. Narrow screens / reduced motion stack everything instead.

### Spacing tweak
Two Ways section gets bottom padding; stacked pathway groups (Primary / Secondary) get extra gap; Pathways → Blended padding tightened via `section--tight-bottom/top`.

### Paint-stroke reveal (Education → Culturally Responsive Education Program)
New section type `paintreveal` (`js/render/paint.js`, `js/fx/paint.js`, `scss/components/_paint.scss`): title left (sticky), copy right revealed by 9 angled brush strokes (CSS mask) as you scroll. Static/unmasked under reduced motion.

### Paint reveal v2
Dark section; red panel is painted on by canvas-drawn dry-brush textures (CSS mask) revealing the white copy; section pins vertically centred and holds before the strokes begin (`js/fx/paint.js`, `_paint.scss`). Narrow screens / reduced motion: static red panel.

### Paint reveal v3
11 strokes alternating direction (L→R, R→L, …); extra vertical padding so a stroke of paint sits above and below the copy.

### Responsive audit
Swept all 8 pages at 15 viewports (320→3440 wide, portrait and landscape phones/tablets) for horizontal overflow, script errors and tap-target size.
- New `scss/components/_touch.scss`: ≥44px hit areas on touch screens (header buttons, chips, footer links, calendar items, pagers…); long button labels wrap on small phones; long words/URLs wrap; type scales gently above 1920px.
- Referral page: download buttons / info callout no longer overflow at 320–360px.
- How It Works (stacked layout): removed the stray top offset left over from the pinned layout.
- Paint reveal: on windows too short to pin it (e.g. 1280×720), it scrolls normally and paints as it passes.

- Fix: Two Ways to Join no longer overlaps its two texts in the stacked (mobile/tablet) layout.

### Enrolment restyle
Enrolment now reuses the site's layouts: sun 'important date' prose (as Payments), framed statement overview (as Education), the stage sequence 'Three ways to enrol' (as Home), and side-by-side tabs (as Payments) for Home-based → School-based → Blended, in tonal alternation. Hero chips reordered to match.

- 

- Cards inside side-tab panels are full-width rows (title left, text right).
- Side tabs scroll back to the top of the option buttons (not the section).
